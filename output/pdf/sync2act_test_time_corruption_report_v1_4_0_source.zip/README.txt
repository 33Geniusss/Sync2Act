Sync2Act cumulative training and test corruption report v1_4_0

Integrates all v1_3_0 evidence with test-corruption results into one narrative,
with shared methods and conclusions. Original sources are in historical/.
Compile with XeLaTeX (not pdfLaTeX). In Overleaf select XeLaTeX and
choose the Chinese source or its _en.tex English counterpart as main.
Use TeX Live with CTeX, PGFPlots, Fandol, and TeX Gyre fonts.
All chart coordinates and tables are embedded. No external assets,
checkpoints, datasets, or Python runtime are needed to compile.

xelatex -interaction=nonstopmode -halt-on-error sync2act_test_time_corruption_report_v1_4_0.tex
xelatex -interaction=nonstopmode -halt-on-error sync2act_test_time_corruption_report_v1_4_0_en.tex
Run each command twice to stabilize bookmarks.

evidence/ contains source summaries and metrics, not the original
robot datasets or model weights. The provenance JSON records SHA-256
hashes for these exact input files. Full precision is retained there;
printed values are rounded, so a displayed 0.000 may be nonzero.
